RESUME & BIODATA MULTI-PAGE WEBSITE

PAGES
- index.html: Home / resume landing page
- about.html: About and personal biodata
- education.html: Academic history
- skills.html: Technical and soft skills
- projects.html: Project portfolio
- contact.html: Contact details and demo email form
- css/style.css: Responsive styling
- js/script.js: Mobile menu, current year and contact form behavior

EDIT BEFORE PUBLISHING
1. Open this folder in VS Code.
2. Use Find (Ctrl+Shift+F) to replace "Your Full Name", "YourName", sample email, phone and placeholder biodata.
3. Update education, skills and project details with accurate information.
4. In contact.html, replace your.email@example.com in the mailto link and in js/script.js with your actual public contact email.
5. Do not publish private information such as full home address, date of birth or personal phone number unless you intentionally want it public.
6. Test index.html in a browser. For local development, VS Code Live Server is convenient.

HOST FREE WITH GITHUB PAGES
1. Sign in or create an account at https://github.com/.
2. Create a new public repository, for example: resume-portfolio.
3. Upload all files and folders from this project. Keep index.html in the repository root.
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for deployment. Your site URL will look like:
   https://YOUR-USERNAME.github.io/resume-portfolio/
8. If you update files later, commit/push the changes; Pages will redeploy.

NOTE
This is a static front-end site. The contact form opens the visitor's email application and does not save messages. A real server-side form requires a backend or form service.
